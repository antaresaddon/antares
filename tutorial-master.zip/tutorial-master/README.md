# tutorial
Este repositorio es para todas las personas que quieren aprender de como crear su propio, repositorio, addons, skins, para Kodi. Sientase libre de copiar toda la programacion. Aqui se promociona el Open Source y compartir el conocimiento de lo aprendido. espero que les sirva de algo. 
